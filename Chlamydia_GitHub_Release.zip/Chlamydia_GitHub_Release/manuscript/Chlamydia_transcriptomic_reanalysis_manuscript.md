# A cross-context reanalysis of host transcriptional responses to *Chlamydia trachomatis* infection

## Abstract

### Background
Host responses to *Chlamydia trachomatis* are shaped by epithelial cell identity, developmental stage of infection and the signalling history of innate immune cells. Public RNA-seq datasets provide an opportunity to test which transcriptional responses recur across models, but differences in platform, cell state and experimental design make direct pooling inappropriate.

### Methods
The uploaded notebook reanalysed five human Gene Expression Omnibus (GEO) series: HCEC and vaginal epithelial cells (GSE198272 and GSE228774), End1/E6E7 endocervical cells infected with serovar L2 or B (GSE180782), HeLa cells infected with serovar E at 20 or 44 h with or without IFN-γ (GSE158814), and monocyte-derived macrophages trained with zymosan, depleted zymosan or β-glucan (GSE242947). Processed count files were parsed into gene-symbol matrices. Differential expression used DESeq2 negative-binomial models with Benjamini–Hochberg correction. Cross-context concordance was assessed with Spearman correlation and directional agreement, and preranked GSEA was performed against MSigDB Hallmark, Reactome, GO biological-process and prespecified innate-immunity gene sets.

### Results
The reanalysis identified 549 genes that were significantly altered in the same direction across four epithelial infection contrasts: HCEC, vaginal epithelial cells, and End1/E6E7 cells infected with L2 or B. The shared signal included IFIT1, IFIT3, ISG15, OASL, RSAD2, CXCL10, CXCL11, CCL5, IL6, IL8, CSF2 and TNFAIP3. HCEC and vaginal epithelial responses were positively correlated (ρ=0.610), and HCEC responses correlated most strongly with End1/E6E7 L2 infection (ρ=0.724). Concordance with HeLa was weaker and context-dependent, ranging from ρ=0.010 for 44 h infection to ρ=0.194 for 20 h infection and ρ=0.190 for 44 h infection under IFN-γ. Of the 549 core genes, 69.5% showed the same direction at 20 h in HeLa, compared with 37.8% at 44 h and 51.4% at 44 h with IFN-γ. Macrophage-training contrasts showed low correlation with epithelial infection contrasts, indicating that trained-immunity transcriptional states should not be treated as interchangeable with epithelial infection responses.

### Conclusions
Across independent epithelial models, *C. trachomatis* infection is associated with a reproducible interferon- and inflammatory-response component, but the magnitude and transferability of the response depend strongly on cell identity, time and cytokine context. The results support a conserved host-response module while arguing against a universal “Chlamydia signature” detached from biological context. The macrophage analyses are best interpreted as a mechanistic comparator rather than external validation of epithelial infection.

**Keywords:** *Chlamydia trachomatis*; RNA-seq; differential expression; epithelial cells; interferon; trained immunity; Gene Expression Omnibus; reanalysis

## Introduction

*C. trachomatis* is an obligate intracellular pathogen whose developmental cycle and tissue tropism expose host cells to changing intracellular and inflammatory environments. Infection can produce both protective immunity and tissue-damaging inflammation. In the female genital tract, repeated or persistent infection has been linked to fibrotic sequelae, and work associated with GSE198272/GSE228774 has implicated infection-induced YAP activity and epithelial–fibroblast signalling in this process (Caven and Carabeo, 2023; NCBI GEO, 2023a, 2023b).

The transcriptional response is not expected to be identical in every model. Endocervical and vaginal epithelial cells differ in lineage and baseline state; HeLa cells are transformed and were profiled at different points in the chlamydial developmental cycle; and macrophage-training experiments interrogate prior exposure to Dectin-1 ligands rather than infection itself. The HeLa study specifically reported stage-associated host transcriptional differences and a strong effect of IFN-γ at 44 h (Dzakah *et al*., 2021). The macrophage study likewise showed that zymosan and β-glucan can induce distinct training phenotypes, despite overlapping receptor biology (Cheng *et al*., 2024).

This study therefore treats the uploaded notebook as a cross-context reanalysis, not as a pooled experiment. The primary question was whether a directionally consistent epithelial response could be identified across independent infection contrasts. Secondary questions were whether that signal transferred to HeLa infection at different stages and whether it resembled transcriptional states induced by macrophage training. This framing is consistent with the intended use of GEO as a source for transparent re-use and re-analysis of public functional-genomics data (Clough and Barrett, 2016; Weintraub *et al*., 2024).

## Materials and methods

### Data sources and sample selection

The notebook downloaded supplementary files from five GEO series and retained the following contrasts. GSE228774 supplied three mock and three L2-infected vaginal epithelial-cell replicates; GSE198272 supplied three mock and three L2-infected endocervical epithelial-cell replicates. GSE180782 supplied three mock, three L2-infected and three B-infected End1/E6E7-cell replicates. GSE158814 supplied two replicates for each of the selected HeLa conditions: infection at 20 h, infection at 44 h, infection at 44 h under IFN-γ, and the corresponding controls as encoded by the notebook. GSE242947 supplied two donor replicates at 0, 1 and 3 h for untrained, zymosan-trained, β-glucan-trained and depleted-zymosan-trained macrophages. The GEO records describe the source experiments and provide the processed data files used here (NCBI GEO, 2021, 2023a, 2023b, 2024).

For GSE228774 and GSE198272, per-sample CLC spreadsheets were read from the `Name`, `ENSEMBL` and `Total gene reads` columns. Gene symbols were upper-cased and duplicate symbols were summed. For GSE180782, the same approach was applied to the End1/E6E7 CLC files. For GSE158814, only entries annotated as mRNA, protein or coding were retained; duplicate gene symbols were summed. The HeLa count matrix contained non-integer values and was rounded before DESeq2 analysis. For GSE242947, Ensembl identifiers were stripped of version suffixes and mapped to gene symbols using the mapping accumulated from the epithelial CLC files. The notebook reported that 82.9% of macrophage Ensembl identifiers were mapped. This cross-study mapping strategy is a potential source of gene-selection bias and is retained as a limitation rather than treated as a neutral preprocessing step.

No samples were excluded. The notebook recorded a fixed random seed of 42, package versions, downloaded-file MD5 hashes and the absence of explicit sample exclusions.

### Quality control and normalization

Quality control used log2 counts per million, filtering genes with counts ≥10 in at least two samples. Principal-component analysis was performed on the 2,000 most variable retained genes, and Spearman sample-correlation heatmaps were generated. Library sizes ranged from 12.34 to 38.94 million counted reads across the four analytical contexts. These plots were used descriptively; no post hoc exclusion was applied.

### Differential expression

Differential expression was performed with PyDESeq2 0.6.0, an implementation of the DESeq2 framework. Count matrices were rounded to integers where necessary and genes were retained when they had counts ≥10 in at least two samples. The model used the relevant condition factor and, for macrophage contrasts, donor as a covariate because the design was paired by donor. DESeq2 fits negative-binomial generalized linear models and uses Wald tests for coefficient contrasts; the notebook then recalculated Benjamini–Hochberg adjusted values from the returned P values (Love, Huber and Anders, 2014; Benjamini and Hochberg, 1995). Statistical significance was defined as adjusted P<0.05. The notebook’s primary significant-gene counts are reported without imposing an additional fold-change threshold, because the threshold was not used for the DE tables themselves.

The four epithelial “core” contrasts were HCEC infection versus mock, vaginal epithelial-cell infection versus mock, End1/E6E7 L2 versus mock and End1/E6E7 B versus mock. HeLa contrasts were treated as validation contexts. A gene was called core-conserved when it was significant in all four core contrasts and had the same sign of log2 fold change in all four.

### Concordance, validation and pathway analysis

For each pair of infection contrasts, the notebook calculated Spearman correlation of log2 fold changes across shared genes. It also calculated the fraction of genes significant in the first contrast that had the same sign in the second, together with a two-sided binomial test against 0.5. These statistics are descriptive measures of transferability, not estimates of a common biological effect size.

Preranked GSEA used the DESeq2 statistic as the ranking metric and 1,000 permutations, with MSigDB Hallmark 2020, Reactome 2022, GO Biological Process 2023 and four custom gene sets. Prespecified terms were selected by keywords relating to NF-κB, interferon, TNF, interleukin-1, NLRP3, STING, Dectin-1 and P2X signalling. GSEA is appropriate for asking whether pathway members accumulate at the extremes of a ranked list, but its output remains dependent on the gene-set database, identifier mapping and the correlation structure of the input data (Subramanian *et al*., 2005). Because the notebook extract does not retain term-level tables in the recorded output, this manuscript does not make individual pathway-enrichment claims beyond describing the analysis performed.

## Results

### Data structure and differential-expression yield

The epithelial HCEC/HVE matrix contained 9,069 genes across 12 samples. The End1/E6E7 matrix contained 57,769 genes across nine samples, the HeLa matrix 18,561 genes across ten samples and the macrophage matrix 52,005 genes across 24 samples. The number of FDR-significant genes varied widely: 7,933 in HCEC infection, 2,177 in HVE infection, 2,673 in End1 L2 infection and 7,701 in End1 B infection. The HeLa contrasts yielded 9,318, 8,535 and 5,779 significant genes at 20 h, 44 h and 44 h with IFN-γ, respectively. Macrophage-training contrasts yielded 437–1,259 significant genes depending on ligand and time.

These counts should not be interpreted as directly comparable measures of biological intensity. They arise from different platforms, sample sizes, control definitions, cell states and count distributions. In particular, the very large numbers in several epithelial and HeLa contrasts indicate broad transcriptional displacement and/or strong power, but do not by themselves establish that most of the transcriptome is mechanistically specific to infection.

### A conserved epithelial response

The four core epithelial contrasts yielded 549 genes that met the notebook’s stringent definition of significance and same-direction change in all four contrasts. The most prominent named genes in the recorded output included IFIT1, IFIT3, ISG15, OASL and RSAD2, together with the chemokines CXCL10, CXCL11 and CCL5, the inflammatory genes IL6, IL8 and CSF2, and the negative-feedback regulator TNFAIP3. The presence of these genes is consistent with a conserved interferon/inflammatory component, but the reanalysis does not establish whether the component is driven by a single upstream sensor in every model. Experimental work has linked *C. trachomatis* infection to STING-dependent type-I-interferon and inflammasome responses in myeloid cells, but that mechanistic evidence should not be projected uncritically onto epithelial transcriptomes (Webster *et al*., 2017).

The direct HCEC–HVE comparison identified 2,802 genes with a significant difference between infection-associated fold changes. This result supports cell-type dependence rather than a uniform epithelial programme. It also fits the originating study’s emphasis on tissue-specific YAP activation and fibrotic paracrine signalling (Caven and Carabeo, 2023).

### Transfer to HeLa infection is limited and stage-dependent

The strongest pairwise epithelial concordance was between HCEC and End1/E6E7 L2 infection (ρ=0.724), followed by HCEC and HVE infection (ρ=0.610). Concordance with HeLa was substantially lower. The 20 h HeLa contrast correlated positively with HCEC (ρ=0.194), whereas the 44 h contrast was negatively correlated with HCEC (ρ=−0.135) and HVE (ρ=−0.230). The IFN-γ-conditioned 44 h contrast showed weak concordance with the core epithelial contrasts (ρ=0.059 with HCEC; ρ=0.095 with HVE).

The 549-gene core set gave a similar picture. Same-direction validation occurred for 292 of 420 genes found in the 20 h comparison (69.5%), 155 of 410 genes at 44 h (37.8%) and 216 of 420 genes under IFN-γ (51.4%). The corresponding numbers also significant at FDR<0.05 were 335, 306 and 194. Thus, the core response is more transferable to early HeLa infection than to the later or IFN-γ-conditioned states, but even early transfer is incomplete.

![Spearman concordance across infection contrasts](./chlamydia_concordance_heatmap.png)

*Figure 1. Pairwise Spearman correlations of gene-level log2 fold changes reconstructed from the notebook’s recorded concordance output. The figure is descriptive and does not represent a pooled meta-analysis.*

![Directional validation of the core epithelial signature](./chlamydia_validation.png)

*Figure 2. Directional validation of the 549-gene core set in the three HeLa contrasts. Labels show the fraction with the same sign; the number below each bar is the number also significant at FDR<0.05.*

### Macrophage training is a comparator, not an infection validation set

The notebook compared each epithelial/HeLa infection contrast with nine macrophage-training contrasts. Recorded Spearman correlations were generally low, often near zero and sometimes negative. This weak transfer is biologically plausible. The macrophage dataset measures transcription after prior exposure to Dectin-1 ligands and subsequent LPS stimulation, whereas the epithelial datasets measure acute intracellular infection in non-myeloid cells. Moreover, the source macrophage study showed that untreated zymosan and β-glucan produce distinct training phenotypes, with zymosan engaging stronger NF-κB/AP-1 activity and reducing rather than increasing some cytokine responses (Cheng *et al*., 2024). The present results therefore do not support the claim that a generic trained-immunity programme recapitulates the epithelial *Chlamydia* response.

## Discussion

The principal finding is not that *C. trachomatis* produces one invariant host transcriptome. It is that independent epithelial infection models share a measurable core containing interferon-stimulated genes, chemokines and inflammatory regulators, while the broader response is strongly conditioned by cell identity and infection context. This distinction matters because the same gene can be induced for different proximate reasons in different models. A chemokine-rich epithelial response may reflect pathogen sensing, tissue-specific transcriptional co-regulation, altered cell state or feedback from interferon signalling; the current reanalysis cannot separate these possibilities.

The strongest conservation was observed among the endocervical and vaginal epithelial datasets and the End1/E6E7 L2 contrast. The result is compatible with a shared epithelial response to infection, although the datasets are not biologically identical and were generated on different sequencing platforms. The HCEC–HVE difference analysis further indicates that cell identity modifies the response. This is especially relevant to disease interpretation because the original HCEC/HVE work connects infection-responsive transcription to YAP activity and fibrotic paracrine signalling rather than to inflammation alone.

The HeLa results provide an internal stress test of generalisability. Early infection retained partial directional agreement with the core set, whereas later infection and IFN-γ-conditioned infection did not. The pattern is consistent with temporal remodelling of host transcription and with the source study’s stage-specific results, but it is not proof of a common time-dependent trajectory because the experiments differ in serovar, cell line, platform and control structure.

The macrophage analysis provides a useful negative comparator. Trained immunity is a real form of innate immune memory involving persistent changes in cell physiology, metabolism and chromatin state (Netea *et al*., 2016), but trained states are stimulus-specific. The low cross-context correlations here argue against collapsing infection responses and ligand-trained macrophage states into one broad innate-immune signature.

### Limitations

Several limitations should guide use of the results. First, this is a reanalysis of processed public files, not a new experiment. Second, the datasets differ in cell type, serovar, infection time, IFN-γ exposure, sequencing platform and sample size; no cross-study batch correction or formal meta-analysis was performed. Third, the macrophage Ensembl-to-symbol mapping was inherited from epithelial annotation files and retained only 82.9% of identifiers. Fourth, the HeLa contrasts contain two replicates per condition, and the macrophage contrasts contain two donor replicates per condition/time, limiting precision despite model-based dispersion estimation. Fifth, the HCEC/HVE and End1 comparisons do not constitute a fully crossed factorial design, so cell-type differences and study-specific technical effects cannot be separated completely. Finally, the pathway analysis included custom gene sets and multiple libraries; without the term-level output in the notebook record, pathway-level biological claims should be made only after inspecting the exported GSEA tables.

## Conclusion

The uploaded analyses support a conservative model of *C. trachomatis* host response: a reproducible epithelial interferon/inflammatory core is present across several independent infection contrasts, but its surrounding transcriptional landscape is cell- and stage-dependent. HCEC, HVE and End1/E6E7 models show the clearest transferability; HeLa provides only partial, time-dependent validation; and macrophage training is a mechanistically distinct comparator. The core genes and exported tables provide a defensible basis for follow-up experiments, but not for claims of a universal pathogen-specific signature or a direct equivalence between epithelial infection and trained immunity.

## Data and code availability

The reanalysed data are available from NCBI GEO under GSE198272, GSE228774, GSE180782, GSE158814 and GSE242947. The uploaded notebook records the download logic, sample parsing, analysis parameters, package versions, random seed, file hashes and result-export commands. The manuscript’s figures were reconstructed from the notebook’s recorded concordance and validation outputs.

## References

Benjamini, Y. and Hochberg, Y. (1995) ‘Controlling the false discovery rate: a practical and powerful approach to multiple testing’, *Journal of the Royal Statistical Society: Series B (Methodological)*, 57(1), pp. 289–300. doi: 10.1111/j.2517-6161.1995.tb02031.x.

Caven, L. and Carabeo, R. (2023) ‘Chlamydial YAP activation in host endocervical epithelial cells mediates pro-fibrotic paracrine stimulation of fibroblasts’, *mSystems*, 8(6), e0090423. doi: 10.1128/msystems.00904-23.

Cheng, Q.J. *et al.* (2024) ‘Dectin-1 ligands produce distinct training phenotypes in human monocytes through differential activation of signaling networks’, *Scientific Reports*, 14, 1454. doi: 10.1038/s41598-024-51620-8.

Clough, E. and Barrett, T. (2016) ‘The Gene Expression Omnibus database’, in *Statistical Genomics*. Methods in Molecular Biology, 1418, pp. 93–110. doi: 10.1007/978-1-4939-3578-9_5.

Dzakah, E.E. *et al.* (2021) ‘Host cell response and distinct gene expression profiles at different stages of *Chlamydia trachomatis* infection reveals stage-specific biomarkers of infection’, *BMC Microbiology*, 21, 3. doi: 10.1186/s12866-020-02061-6.

Love, M.I., Huber, W. and Anders, S. (2014) ‘Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2’, *Genome Biology*, 15, 550. doi: 10.1186/s13059-014-0550-8.

NCBI GEO (2021) ‘GSE158814: Genome-wide analysis of *Chlamydia trachomatis*-infected cells’. National Center for Biotechnology Information. Available at: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE158814 (Accessed: 21 November 2026).

NCBI GEO (2023a) ‘GSE198272: *Chlamydia trachomatis* induces the transcriptional activity of host YAP in a Hippo-independent fashion’. National Center for Biotechnology Information. Available at: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE198272 (Accessed: 21 November 2026).

NCBI GEO (2023b) ‘GSE228774: Cell type-intrinsic differences in the host transcriptome of *Chlamydia trachomatis*-infected primary human endocervical epithelial cells and vaginal epithelial cells’. National Center for Biotechnology Information. Available at: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE228774 (Accessed: 21 November 2026).

NCBI GEO (2023c) ‘GSE180782: *Chlamydia trachomatis* induces the transcriptional activity of host YAP in a Hippo-independent fashion’. National Center for Biotechnology Information. Available at: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE180782 (Accessed: 21 November 2026).

NCBI GEO (2024) ‘GSE242947: Dectin-1 ligands produce distinct training phenotypes in human monocytes through differential activation of signaling networks’. National Center for Biotechnology Information. Available at: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE242947 (Accessed: 21 November 2026).

Netea, M.G. *et al.* (2016) ‘Trained immunity: a program of innate immune memory in health and disease’, *Science*, 352(6284), aaf1098. doi: 10.1126/science.aaf1098.

Subramanian, A. *et al.* (2005) ‘Gene set enrichment analysis: a knowledge-based approach for interpreting genome-wide expression profiles’, *Proceedings of the National Academy of Sciences of the United States of America*, 102(43), pp. 15545–15550. doi: 10.1073/pnas.0506580102.

Webster, S.J. *et al.* (2017) ‘Detection of a microbial metabolite by STING regulates inflammasome activation in response to *Chlamydia trachomatis* infection’, *PLOS Pathogens*, 13(6), e1006383. doi: 10.1371/journal.ppat.1006383.

Weintraub, J.T. *et al.* (2024) ‘The NCBI Gene Expression Omnibus database: 20 years of data deposition and mining’, *Nucleic Acids Research*, 52(D1), pp. D138–D144. doi: 10.1093/nar/gkad965.
